package com.springcore.ci;

public class Addition 
{
int a,b;
public Addition(int  a, int b)
{
	this.a=a;
	this.b=b;
	System.out.println("Constructor : int,int");
}

}
