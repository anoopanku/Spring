package com.springcore.javaconfig;

import org.springframework.stereotype.Component;

@Component("ob")
public class Student 
{
	public void study()
	{
		System.out.println("Student Studying");
	}
}
