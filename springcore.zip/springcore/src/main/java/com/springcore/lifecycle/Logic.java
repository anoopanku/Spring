package com.springcore.lifecycle;

public class Logic 
{
private double item;

public double getItem() {
	return item;
}

public void setItem(double item) {
	System.out.println("Setting price");
	this.item = item;
}

public Logic() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Logic [item=" + item + "]";
}
public void init()
{
	System.out.println("inside init");
}
public void destroy()
{
	System.out.println("Inside destroy");
}
}
