package com.springcore.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Logic2 implements InitializingBean, DisposableBean
{
private double item;

public double getItem() {
	return item;
}

public void setItem(double item) {
	this.item = item;
}

public Logic2() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Logic2 [item=" + item + "]";
}

public void afterPropertiesSet() throws Exception 
{
	// TODO Auto-generated method stub
	System.out.println("Init Method");
	
}

public void destroy() throws Exception {
	// TODO Auto-generated method stub
	System.out.println("Going to destroy");
	
}

}
