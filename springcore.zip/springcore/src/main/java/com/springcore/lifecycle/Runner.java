package com.springcore.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Runner 
{
public static void main(String a[])
{
	AbstractApplicationContext ac=new ClassPathXmlApplicationContext("com/springcore/lifecycle/lifeconfig.xml");
	Logic l1=(Logic)ac.getBean("l1");
	System.out.println(l1);
	ac.registerShutdownHook();
	System.out.println("+++++++++++++++++++++++++++++++++++++");
	Logic2 l2=(Logic2)ac.getBean("l2");
	System.out.println(l2);
}
}
