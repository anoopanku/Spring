package com.springcore.ref;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/ref/refconfig.xml");
		A t1=(A)context.getBean("aref");
		System.out.println(t1.getA());
		System.out.println(t1.getOb().getY());
		System.out.println(t1);
	}

}
