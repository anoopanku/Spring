package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping("/")
public String home(Model model)
{
		System.out.println("This is Index Page");
		model.addAttribute("name","Anoop");
return "index";	
}
	@RequestMapping("/about")
	public String about() {
		System.out.println("This is About PAge");
		return "about";
	}
	
}
